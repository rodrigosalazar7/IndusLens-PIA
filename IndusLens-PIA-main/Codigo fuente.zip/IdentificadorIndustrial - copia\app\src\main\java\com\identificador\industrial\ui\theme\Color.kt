package com.identificador.industrial.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Paleta industrial: fondos oscuros con naranja de seguridad como color de accion.
 * El fondo oscuro no es solo estetico, en almacenes y naves con poca luz cansa
 * menos la vista y la pantalla se lee mejor a contraluz.
 */

// Color de accion principal (naranja de seguridad industrial)
val NaranjaSeguridad = Color(0xFFFF7A1A)
val NaranjaClaro = Color(0xFFFFA45C)
val NaranjaOscuro = Color(0xFFC85A00)

// Acento secundario (azul acero) para informacion y enlaces
val AzulAcero = Color(0xFF4A9EDB)
val AzulAceroOscuro = Color(0xFF1F4E6E)

// Superficies
val FondoBase = Color(0xFF0F1419)
val Superficie = Color(0xFF16202B)
val SuperficieAlta = Color(0xFF1E2A38)
val Borde = Color(0xFF2C3B4C)

// Texto
val TextoPrincipal = Color(0xFFE6EDF3)
val TextoSecundario = Color(0xFF9AA7B4)

// Estados
val VerdeExito = Color(0xFF3FB950)
val AmarilloAviso = Color(0xFFD29922)
val RojoError = Color(0xFFE5484D)
