package com.identificador.industrial.ui.pantallas

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.identificador.industrial.ia.Fotos
import com.identificador.industrial.ui.componentes.PantallaBase
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Pantalla 3: camara.
 *
 * No sabe para que se usa la foto: solo la entrega. Asi la misma pantalla
 * sirve tanto para identificar una pieza como para ensenarle una nueva a la
 * aplicacion, sin duplicar toda la gestion de camara y permisos.
 */
@Composable
fun PantallaCamara(
    titulo: String,
    textoGuia: String,
    onVolver: () -> Unit,
    onFotoTomada: (android.net.Uri) -> Unit
) {
    val contexto = LocalContext.current
    val cicloVida = LocalLifecycleOwner.current

    var permisoConcedido by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(contexto, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var permisoRechazado by remember { mutableStateOf(false) }
    var errorCamara by remember { mutableStateOf<String?>(null) }
    var linternaEncendida by remember { mutableStateOf(false) }
    var capturando by remember { mutableStateOf(false) }
    var camara by remember { mutableStateOf<Camera?>(null) }

    val vistaPrevia = remember {
        PreviewView(contexto).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }
    val captura = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }

    val pedirPermiso = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedido ->
        permisoConcedido = concedido
        permisoRechazado = !concedido
    }

    // Alternativa a la camara: elegir una foto ya existente. Util para probar
    // sin tener la pieza delante y para fotos tomadas antes por otra persona.
    val elegirDeGaleria = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onFotoTomada(uri)
    }

    LaunchedEffect(Unit) {
        if (!permisoConcedido) pedirPermiso.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(permisoConcedido) {
        if (!permisoConcedido) return@LaunchedEffect
        try {
            val proveedor = proveedorDeCamara(contexto)
            val previa = Preview.Builder().build()
            previa.setSurfaceProvider(vistaPrevia.surfaceProvider)
            proveedor.unbindAll()
            camara = proveedor.bindToLifecycle(
                cicloVida,
                CameraSelector.DEFAULT_BACK_CAMERA,
                previa,
                captura
            )
        } catch (e: Exception) {
            errorCamara = e.message ?: "No se pudo abrir la camara"
        }
    }

    // Al salir de la pantalla se apaga la linterna: si no, se queda encendida
    // consumiendo bateria y calentando el equipo sin que nadie lo note.
    DisposableEffect(Unit) {
        onDispose { camara?.cameraControl?.enableTorch(false) }
    }

    fun disparar() {
        // Una sola captura por pulsacion. Sin esta guarda, un segundo disparo
        // -por un toque repetido o por un reintento de CameraX- entrega una
        // foto tardia que pisa el analisis ya en marcha.
        if (capturando) return
        capturando = true

        captura.takePicture(
            ContextCompat.getMainExecutor(contexto),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        onFotoTomada(Fotos.guardarCaptura(contexto, image))
                    } catch (e: Exception) {
                        errorCamara = e.message ?: "No se pudo guardar la fotografia"
                    } finally {
                        image.close()
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    capturando = false
                    errorCamara = exception.message ?: "Fallo al tomar la fotografia"
                }
            }
        )
    }

    PantallaBase(titulo = titulo, onVolver = onVolver) { modifier ->
        Box(modifier = modifier.fillMaxSize()) {

            when {
                !permisoConcedido -> SinPermiso(
                    rechazado = permisoRechazado,
                    onReintentar = { pedirPermiso.launch(Manifest.permission.CAMERA) },
                    onGaleria = {
                        elegirDeGaleria.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                )

                errorCamara != null -> Mensaje(
                    texto = "No se pudo iniciar la camara.\n$errorCamara"
                )

                else -> {
                    AndroidView(
                        factory = { vistaPrevia },
                        modifier = Modifier.fillMaxSize()
                    )
                    MarcoGuia(textoGuia)
                    ControlesCamara(
                        linternaEncendida = linternaEncendida,
                        hayLinterna = camara?.cameraInfo?.hasFlashUnit() == true,
                        capturando = capturando,
                        onDisparar = { disparar() },
                        onLinterna = {
                            linternaEncendida = !linternaEncendida
                            camara?.cameraControl?.enableTorch(linternaEncendida)
                        },
                        onGaleria = {
                            elegirDeGaleria.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                }
            }
        }
    }
}

/**
 * Marco que indica donde encuadrar la pieza.
 *
 * No recorta nada: el analisis usa la foto completa. Sirve para que el
 * operador acerque y centre la pieza, que es lo que de verdad mejora la
 * lectura del numero de parte.
 */
@Composable
private fun MarcoGuia(texto: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .border(
                        width = 2.dp,
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(20.dp)
                    )
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = texto,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .background(
                        color = Color.Black.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun ControlesCamara(
    linternaEncendida: Boolean,
    hayLinterna: Boolean,
    capturando: Boolean,
    onDisparar: () -> Unit,
    onLinterna: () -> Unit,
    onGaleria: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(vertical = 20.dp, horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onGaleria) {
                Text("Galeria", color = Color.White)
            }

            // Boton de disparo grande: se usa con guantes de trabajo.
            Box(
                modifier = Modifier
                    .size(74.dp)
                    .background(color = Color.White, shape = CircleShape)
                    .padding(6.dp)
            ) {
                Button(
                    onClick = onDisparar,
                    enabled = !capturando,
                    shape = CircleShape,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    modifier = Modifier.fillMaxSize()
                ) {}
            }

            TextButton(onClick = onLinterna, enabled = hayLinterna) {
                Text(
                    text = if (linternaEncendida) "Apagar luz" else "Luz",
                    color = if (hayLinterna) Color.White else Color.White.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@Composable
private fun SinPermiso(
    rechazado: Boolean,
    onReintentar: () -> Unit,
    onGaleria: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (rechazado) {
                "La aplicacion necesita la camara para fotografiar la pieza. " +
                    "Sin ese permiso no se puede identificar nada."
            } else {
                "Concede el permiso de camara para continuar."
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onReintentar, shape = RoundedCornerShape(12.dp)) {
            Text("Conceder permiso")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onGaleria, shape = RoundedCornerShape(12.dp)) {
            Text("Elegir una foto de la galeria")
        }
    }
}

@Composable
private fun Mensaje(texto: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = texto,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

/**
 * CameraX entrega su proveedor mediante un ListenableFuture de Guava.
 * Este envoltorio lo convierte en algo que se puede esperar con corrutinas.
 */
private suspend fun proveedorDeCamara(contexto: Context): ProcessCameraProvider =
    suspendCancellableCoroutine { continuacion ->
        val futuro = ProcessCameraProvider.getInstance(contexto)
        futuro.addListener(
            {
                try {
                    continuacion.resume(futuro.get())
                } catch (e: Exception) {
                    continuacion.resumeWithException(e)
                }
            },
            ContextCompat.getMainExecutor(contexto)
        )
    }
